package com.poc.pdfgenerator;


import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.poc.pdfgenerator.model.PDFData;
import com.poc.pdfgenerator.model.TranscationInformation;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;


public class BankStatementGenerator {
    private PDFData pdfData;
    private Date reportGeneratedDate;
    private String reportGeneratedDateStr;
    private static final SimpleDateFormat footerDateFormatter = new SimpleDateFormat("HH:mm dd-MM-yyyy");
    private static final SimpleDateFormat dataDateFormatter = new SimpleDateFormat("dd-MM-yyyy");

    private Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);

    public BankStatementGenerator(PDFData pdfData, Date reportGeneratedDate) {
        this.pdfData = pdfData;
        this.reportGeneratedDate = reportGeneratedDate;
        this.reportGeneratedDateStr = BankStatementGenerator.footerDateFormatter.format(this.reportGeneratedDate);
    }

    public void generatePdf(String dest) throws Exception {
        RectangleReadOnly rectangleReadOnly = new RectangleReadOnly(960F, 540F);
        Document document = new Document(rectangleReadOnly, 36, 36, 180, 36);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(dest));

        HeaderFooterEventHandler event = new HeaderFooterEventHandler();
        writer.setPageEvent(event);

        document.open();
        document.add(this.getAccountDetailsTable());
        LineSeparator lineSeparator = new LineSeparator();
        lineSeparator.setOffset(-5);
        document.add(lineSeparator);
        document.add(Chunk.NEWLINE);
        document.add(this.getTransactionsTable());
        document.close();
    }

    public PdfPTable getAccountDetailsTable() {
        PdfPTable accountDetailsTable = null;

        try {
            accountDetailsTable = new PdfPTable(2);
            accountDetailsTable.setWidthPercentage(100f);
            accountDetailsTable.setWidths(new int[]{50, 50});
            accountDetailsTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            accountDetailsTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            accountDetailsTable.addCell(new Phrase(String.format("Account name: %s", pdfData.getAccount_name()), headerFont));
            accountDetailsTable.addCell(new Phrase(String.format("Statement date range: %s", pdfData.getDate_range()), headerFont));
            accountDetailsTable.addCell(new Phrase(String.format("Account number: %s", pdfData.getAccount_name()), headerFont));
            accountDetailsTable.addCell(new Phrase(String.format("Closing balance: %s", pdfData.getDate_range()), headerFont));
        } catch (Exception documentException) {
            documentException.printStackTrace();
        }
        return accountDetailsTable;
    }

    public PdfPTable getTransactionsTable()
            throws DocumentException, IOException {
        String cellText;
        Font tableHeaderFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, new BaseColor(255, 255, 255));
        BaseColor dataOddRowColor = new BaseColor(210, 222, 239);
        BaseColor dataEvenRowColor = new BaseColor(234, 239, 247);
        PdfPTable reportTable = new PdfPTable(7);
        PdfPCell cell;
        reportTable.setWidthPercentage(100f);
        reportTable.setSpacingBefore(10);
        reportTable.setSpacingAfter(10);
        reportTable.getDefaultCell().setUseAscender(true);
        reportTable.getDefaultCell().setUseDescender(true);
//        reportTable.getDefaultCell().setBackgroundColor(BaseColor.LIGHT_GRAY);
        float[] columnWidths = new float[]{10, 30, 15, 15, 15, 8, 7};
        reportTable.setWidths(columnWidths);
        reportTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
        reportTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
        reportTable.getDefaultCell().setBackgroundColor(new BaseColor(0, 0, 0));
        reportTable.getDefaultCell().setBorderColor(new BaseColor(255, 255, 255));
        reportTable.getDefaultCell().setPadding(5);
        reportTable.addCell(new Paragraph("Posting Date", tableHeaderFont));
        reportTable.addCell(new Paragraph("Transaction Description", tableHeaderFont));
        reportTable.addCell(new Paragraph("Transaction Type", tableHeaderFont));
        reportTable.addCell(new Paragraph("Value Date", tableHeaderFont));
        reportTable.addCell(new Paragraph("Value", tableHeaderFont));
        reportTable.addCell(new Paragraph("Currency", tableHeaderFont));
        reportTable.addCell(new Paragraph("Debit or Credit", tableHeaderFont));

        if (!Objects.isNull(pdfData.getTranscationInformations())) {
            reportTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            reportTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
            reportTable.getDefaultCell().setBackgroundColor(null);
            reportTable.setHeaderRows(1);
            String transactionFormattedDate = "";
            boolean odd = true;
            BaseColor currentFont;
            BaseColor dataBorderColor = new BaseColor(255, 255, 255);
            for (TranscationInformation transcationInformation : pdfData.getTranscationInformations()) {
                if (odd) {
                    currentFont = dataOddRowColor;
                } else {
                    currentFont = dataEvenRowColor;
                }
                odd = !odd;

//                transcationInformation.getPosting_date()
//                transcationInformation.getPosting_date()
                transactionFormattedDate = "";
                if (transcationInformation.getPosting_date() != null) {
                    transactionFormattedDate = dataDateFormatter.format(transcationInformation.getPosting_date());
                }

                cell = new PdfPCell(new Paragraph(transactionFormattedDate));
                cell.setBackgroundColor(currentFont);
                cell.setBorderColor(dataBorderColor);
                cell.setPadding(5);
                reportTable.addCell(cell);
                cell = new PdfPCell(new Paragraph(transcationInformation.getTranscation_description()));
                cell.setBackgroundColor(currentFont);
                cell.setBorderColor(dataBorderColor);
                cell.setPadding(5);
                reportTable.addCell(cell);
                cell = new PdfPCell(new Paragraph(transcationInformation.getTranscation_type()));
                cell.setBackgroundColor(currentFont);
                cell.setBorderColor(dataBorderColor);
                cell.setPadding(5);
                reportTable.addCell(cell);
                cell = new PdfPCell(new Paragraph(transactionFormattedDate));
                cell.setBackgroundColor(currentFont);
                cell.setBorderColor(dataBorderColor);
                cell.setPadding(5);
                reportTable.addCell(cell);
                cell = new PdfPCell(new Paragraph(transcationInformation.getValue()));
                cell.setBackgroundColor(currentFont);
                cell.setBorderColor(dataBorderColor);
                cell.setPadding(5);
                reportTable.addCell(cell);
                cell = new PdfPCell(new Paragraph(transcationInformation.getCurrenty()));
                cell.setBackgroundColor(currentFont);
                cell.setBorderColor(dataBorderColor);
                cell.setPadding(5);
                reportTable.addCell(cell);
                cell = new PdfPCell(new Paragraph(transcationInformation.getDebit_or_credit()));
                cell.setBackgroundColor(currentFont);
                cell.setBorderColor(dataBorderColor);
                cell.setPadding(5);
                reportTable.addCell(cell);
            }
        }
        return reportTable;
    }

    public class HeaderFooterEventHandler extends PdfPageEventHelper {
        private PdfTemplate t;
        private Image total;

        public HeaderFooterEventHandler() {
        }

        public void onOpenDocument(PdfWriter writer, Document document) {
            t = writer.getDirectContent().createTemplate(30, 16);

            try {
                total = Image.getInstance(t);
                total.setRole(PdfName.ARTIFACT);
            } catch (DocumentException de) {
                throw new ExceptionConverter(de);
            }
        }

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            addHeader(writer);
            addFooter(writer);
        }

        private PdfPTable getAccountDetailsTable() {
            PdfPTable accountDetailsTable = new PdfPTable(1);
            accountDetailsTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            accountDetailsTable.addCell(new Phrase(pdfData.getCompany_name(), headerFont));
            if (!Objects.isNull(pdfData.getAddress())) {
                String locationStr = "", locationStrs[] = new String[3];
                if (!Objects.isNull(pdfData.getAddress().getFirst_line()) && !pdfData.getAddress().getFirst_line().isEmpty()) {
                    accountDetailsTable.addCell(new Phrase(pdfData.getAddress().getFirst_line(), headerFont));
                }
                if (!Objects.isNull(pdfData.getAddress().getSecond_line()) && !pdfData.getAddress().getSecond_line().isEmpty()) {
                    accountDetailsTable.addCell(new Phrase(pdfData.getAddress().getSecond_line(), headerFont));
                }
                if (!Objects.isNull(pdfData.getAddress().getThrid_line()) && !pdfData.getAddress().getThrid_line().isEmpty()) {
                    accountDetailsTable.addCell(new Phrase(pdfData.getAddress().getThrid_line(), headerFont));
                }
                if (!Objects.isNull(pdfData.getAddress().getFourth_line()) && !pdfData.getAddress().getFourth_line().isEmpty()) {
                    accountDetailsTable.addCell(new Phrase(pdfData.getAddress().getFourth_line(), headerFont));
                }

                if (!Objects.isNull(pdfData.getAddress().getCity()) && !pdfData.getAddress().getCity().isEmpty()) {
                    locationStrs[0] = pdfData.getAddress().getCity();
                }

                if (!Objects.isNull(pdfData.getAddress().getPostcode()) && !pdfData.getAddress().getPostcode().isEmpty()) {
                    locationStrs[1] = pdfData.getAddress().getPostcode();
                }

                if (!Objects.isNull(pdfData.getAddress().getCity()) && !pdfData.getAddress().getCity().isEmpty()) {
                    locationStrs[2] = pdfData.getAddress().getCity();
                }

            }

            return accountDetailsTable;
        }

        private void addHeader(PdfWriter writer) {
            PdfPTable header = new PdfPTable(2);
            try {
                header.setWidths(new int[]{15, 5});
                header.setTotalWidth(888);
                header.setLockedWidth(true);
                header.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//                header.getDefaultCell().setFixedHeight(200);
                header.getDefaultCell().setBorder(Rectangle.BOTTOM);
                header.getDefaultCell().setBorderColor(BaseColor.LIGHT_GRAY);
                header.addCell(this.getAccountDetailsTable());
                header.addCell(this.getVendorDetails());
                header.writeSelectedRows(0, -1, 34, 501, writer.getDirectContent());

            } catch (DocumentException de) {
                throw new ExceptionConverter(de);
            }
        }

        public PdfPTable getVendorDetails() {
            PdfPTable vendorTable = new PdfPTable(1);
            vendorTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            try {
                Image logo = Image.getInstance(HeaderFooterEventHandler.class.getResource("/logo.jpg"));
                PdfPCell logoCell = new PdfPCell(logo, true);
                logoCell.setFixedHeight(40);
                logoCell.setBorder(Rectangle.NO_BORDER);
                logoCell.setPadding(10);
                vendorTable.addCell(logoCell);

                PdfPCell text = new PdfPCell();
                text.setPaddingBottom(15);
                text.setPaddingLeft(10);
                text.setBorder(Rectangle.NO_BORDER);
                text.setBorderColor(BaseColor.LIGHT_GRAY);
                text.addElement(new Phrase("ICICI", headerFont));
                text.addElement(new Phrase("Madras india", headerFont));
                text.addElement(new Phrase("2 square street", headerFont));
                text.addElement(new Phrase("http://www.google.com", headerFont));
                vendorTable.addCell(text);

            } catch (DocumentException de) {
                throw new ExceptionConverter(de);
            } catch (MalformedURLException e) {
                throw new ExceptionConverter(e);
            } catch (IOException e) {
                throw new ExceptionConverter(e);
            }
            return vendorTable;
        }

        private void addFooter(PdfWriter writer) {
            PdfPTable footer = new PdfPTable(3);
            try {
                footer.setWidths(new int[]{24, 2, 1});
                footer.setTotalWidth(888);
                footer.setLockedWidth(true);
                footer.getDefaultCell().setFixedHeight(40);
                footer.getDefaultCell().setPaddingTop(15);
                footer.getDefaultCell().setBorder(Rectangle.NO_BORDER);

                footer.addCell(new Phrase(String.format("Date document produced %s", reportGeneratedDate), new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL)));

                footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
                footer.addCell(new Phrase(String.format("Page %d of  ", writer.getPageNumber()), new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL)));

                PdfPCell totalPageCount = new PdfPCell(total);
                totalPageCount.setPaddingTop(17);
                totalPageCount.setBorder(Rectangle.NO_BORDER);
                footer.addCell(totalPageCount);

                PdfContentByte canvas = writer.getDirectContent();
                canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
                footer.writeSelectedRows(0, -1, 34, 50, canvas);
                canvas.endMarkedContentSequence();
            } catch (DocumentException de) {
                throw new ExceptionConverter(de);
            }
        }

        public void onCloseDocument(PdfWriter writer, Document document) {
            int totalLength = String.valueOf(writer.getPageNumber()).length();
            int totalWidth = totalLength * 5;
            ColumnText.showTextAligned(t, Element.ALIGN_RIGHT,
                    new Phrase(String.valueOf(writer.getPageNumber()), headerFont),
                    totalWidth, 6, 0);
        }
    }

}
