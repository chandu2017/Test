package com.poc.pdfgenerator.model;

import java.io.Serializable;
import java.util.Date;

public class TranscationInformation implements Serializable {

    private static final long serialVersionUID = -5804286775178994275L;

    private Date posting_date;
    private String transcation_description;
    private String transcation_type;
    private String value;
    private String value_type;
    private String currenty;
    private String debit_or_credit;

    public String getTranscation_type() {
        return transcation_type;
    }

    public void setTranscation_type(String transcation_type) {
        this.transcation_type = transcation_type;
    }

    public String getTranscation_description() {
        return transcation_description;
    }

    public void setTranscation_description(String transcation_description) {
        this.transcation_description = transcation_description;
    }

    public String getCurrenty() {
        return currenty;
    }

    public void setCurrenty(String currenty) {
        this.currenty = currenty;
    }

    public String getDebit_or_credit() {
        return debit_or_credit;
    }

    public void setDebit_or_credit(String debit_or_credit) {
        this.debit_or_credit = debit_or_credit;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue_type() {
        return value_type;
    }

    public void setValue_type(String value_type) {
        this.value_type = value_type;
    }

    public Date getPosting_date() {
        return posting_date;
    }

    public void setPosting_date(Date posting_date) {
        this.posting_date = posting_date;
    }

}
