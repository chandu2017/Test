package com.poc.pdfgenerator.model;

import java.io.Serializable;

public class Address implements Serializable {

    private static final long serialVersionUID = -4069572652857494830L;

    private String first_line;
    private String second_line;
    private String thrid_line;
    private String fourth_line;
    private String country;
    private String postcode;
    private String city;

    public String getFirst_line() {
        return first_line;
    }

    public void setFirst_line(String first_line) {
        this.first_line = first_line;
    }

    public String getSecond_line() {
        return second_line;
    }

    public void setSecond_line(String second_line) {
        this.second_line = second_line;
    }

    public String getThrid_line() {
        return thrid_line;
    }

    public void setThrid_line(String thrid_line) {
        this.thrid_line = thrid_line;
    }

    public String getFourth_line() {
        return fourth_line;
    }

    public void setFourth_line(String fourth_line) {
        this.fourth_line = fourth_line;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }


}
