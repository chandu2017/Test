package com.poc.pdfgenerator;

import com.poc.pdfgenerator.model.Address;
import com.poc.pdfgenerator.model.PDFData;
import com.poc.pdfgenerator.model.TranscationInformation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Application {

    public static void main(String[] args) throws Exception {
        BankStatementGenerator bankStatementGenerator = new BankStatementGenerator(getMockData(), new Date(System.currentTimeMillis()));
        bankStatementGenerator.generatePdf(System.getProperty("user.dir") + "/generateddocs/bank_statement_" + System.currentTimeMillis() + ".pdf");
    }

    public static PDFData getMockData() {
        PDFData pdfData = new PDFData();
        pdfData.setCompany_name("Customer Name");
        pdfData.setAccount_name("xxxxxxxxxx-xxxxxxxxxx-xxxxxxxxxx");
        pdfData.setAccount_number("xx-xx-xx xxxxxxxx");
        pdfData.setDate_range("dd-mm-yyyy to dd-mm-yyyy");
        pdfData.setClosing_balance("xxxxxxxxxxxxxxx CCY");
        Address address = new Address();
        address.setFirst_line("Customer Address line 1");
//        address.setSecond_line("Customer Address line 2");
//        address.setThrid_line("Customer Address line 3");
        address.setFourth_line("Customer Address line 4");
        pdfData.setAddress(address);
        pdfData.setTranscationInformations(getMockTransactions());
        return pdfData;
    }

    public static List<TranscationInformation> getMockTransactions() {
        List<TranscationInformation> transcationInformations = new ArrayList();
        for (int i = 0; i < 195; i++) {
            TranscationInformation transcationInformation = new TranscationInformation();
            transcationInformation.setTranscation_description("Transaction Description " + i);
            transcationInformation.setTranscation_type("Trans_type_" + i);
            transcationInformation.setDebit_or_credit("Debit");
            transcationInformation.setPosting_date(new Date(System.currentTimeMillis()));
            transcationInformations.add(transcationInformation);
        }
        return transcationInformations;

    }
}
