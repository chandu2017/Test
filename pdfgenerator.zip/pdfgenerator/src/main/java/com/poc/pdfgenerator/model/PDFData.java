package com.poc.pdfgenerator.model;

import java.io.Serializable;
import java.util.List;

public class PDFData implements Serializable {

    private static final long serialVersionUID = 7196655272195866129L;

    private String account_name;
    private String account_number;
    private String company_name;
    private String opening_balance;
    private String closing_balance;
    private String date_range;

    private Address address;
    private List<TranscationInformation> transcationInformations;

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getAccount_number() {
        return account_number;
    }

    public void setAccount_number(String account_number) {
        this.account_number = account_number;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getOpening_balance() {
        return opening_balance;
    }

    public void setOpening_balance(String opening_balance) {
        this.opening_balance = opening_balance;
    }

    public String getClosing_balance() {
        return closing_balance;
    }

    public void setClosing_balance(String closing_balance) {
        this.closing_balance = closing_balance;
    }

    public String getDate_range() {
        return date_range;
    }

    public void setDate_range(String date_range) {
        this.date_range = date_range;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public List<TranscationInformation> getTranscationInformations() {
        return transcationInformations;
    }

    public void setTranscationInformations(List<TranscationInformation> transcationInformations) {
        this.transcationInformations = transcationInformations;
    }

}
